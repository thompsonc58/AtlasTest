// AddisonOreileyLab.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
    system("color f0");
    //Display my information
    cout << "\t\t************************" << endl;
    cout << "\t\t* Addisson OReiley Lab *" << endl;
    cout << "\t\t*     Mr. Thompson     *" << endl;
    cout << "\t\t*     CPT 168-A01H     *" << endl;
    cout << "\t\t************************" << endl;
    
    //Declare Variables
    double taxRate = 0.0;
    double tvCost = 0.0;
    double totalCost = 0.0;

    //Input
    cout << "Please enter the TV Cost: "; //prompt for tv cost
    cin >> tvCost;//user input for tv cost
    cout << "Please enter the Tax Rate: ";//prompt for tax rate
    cin >> taxRate;//user input for tax rate
    
    //Process
    totalCost = tvCost + (tvCost * taxRate);

    //Output
    cout << "Total Cost is: $" <<  totalCost << endl;
    cout << "****T H A N K  Y O U ****\n" << endl;
    system("pause");
    return 0;    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
